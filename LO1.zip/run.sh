g++ -std=c++17 -o world-sim main.cpp Swiat.cpp Organizm.cpp Zwierze.cpp Roslina.cpp Wilk.cpp Owca.cpp Lis.cpp Zolw.cpp Antylopa.cpp Trawa.cpp Mlecz.cpp Guarana.cpp WilczeJagody.cpp BarszczSosnowskiego.cpp Czlowiek.cpp -lncurses
./world-sim
